package com.example.security_xss_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityXssDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityXssDemoApplication.class, args);
	}

}
