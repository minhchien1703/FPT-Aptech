package com.example.security_xss_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityXssDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
