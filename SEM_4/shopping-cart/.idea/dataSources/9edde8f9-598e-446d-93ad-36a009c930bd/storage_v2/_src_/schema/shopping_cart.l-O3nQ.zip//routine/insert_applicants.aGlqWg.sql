create
    definer = root@localhost procedure insert_applicants()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i <= 1200 DO
            INSERT INTO applicant (name, status)
            VALUES (CONCAT('Applicant Name ', i), FLOOR(RAND() * 3)); -- status ngẫu nhiên từ 0-2
            SET i = i + 1;
        END WHILE;
END;

